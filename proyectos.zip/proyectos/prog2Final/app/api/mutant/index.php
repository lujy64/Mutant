<?php
    //Incluir librerias
    include "../config.php";
    include "../utils.php";

    //Conexion Base de datos
    $dbConn =  connect($db);

   
    if ($_SERVER['REQUEST_METHOD'] === 'GET')
    {
      
        //Mostrar lista de post
        $sql = $dbConn->prepare("SELECT * FROM mutante");
        $sql->execute();
        $sql->setFetchMode(PDO::FETCH_ASSOC);
        header("HTTP/1.1 200 OK");
        echo json_encode( $sql->fetchAll()  );
        exit();

    } else 

    // Crear un nuevo post
    if ($_SERVER['REQUEST_METHOD'] === 'POST')
    {
        $input=$_POST['dna'];
        //echo '<pre>'; print_r($input); echo '</pre>';
        $my_array_data = json_decode($input);
        //echo '<pre>'; print_r($my_array_data); echo '</pre>';


        if ($my_array_data!=null && $my_array_data!="" && $my_array_data!=0) {

            $condicion=isMutant($my_array_data);
            //echo '<pre>'; print_r($condicion); echo '</pre>';

            if ($condicion== 'true'){

              $condicion="Mutante";

              $cadenaString=implode( $my_array_data ); 

              $sql= "INSERT INTO mutante (dna, condicion) VALUES ('$cadenaString', '$condicion')";
              //echo '<pre>'; print_r($sql); echo '</pre>';

              $statement = $dbConn->prepare($sql);
              bindAllValues($statement, $input);
              $statement->execute();
              $postId = $dbConn->lastInsertId();

              if($postId)
              {
                header("HTTP/1.1 200 OK");
                $ok= array('ok' => array('mensaje' => "Se almaceno correctamento", "datos_Resultado" => array('id' => $postId,"dna"=>$cadenaString,"condicion"=>$condicion)));
                echo json_encode($ok);
                exit();
              }

            } else if ($condicion== 'false'){

              $condicion="Humano";      

              $cadenaString=implode( $my_array_data );     
              
              $sql= "INSERT INTO mutante (dna, condicion) VALUES ('$cadenaString', '$condicion')";
              //echo '<pre>'; print_r($sql); echo '</pre>';
              
              $statement = $dbConn->prepare($sql);
              bindAllValues($statement, $input);
              
              $statement->execute();
              //echo '<pre>'; print_r($statement); echo '</pre>';
              $postId = $dbConn->lastInsertId();
              if($postId)
              {
                header("HTTP/1.1 200 OK");
                $ok= array('ok' => array('mensaje' => "Se almaceno correctamento", "datos_Resultado" => array('id' => $postId,"dna"=>$cadenaString,"condicion"=>$condicion)));
                echo json_encode($ok);
                exit();
              }
            }

        } else {

             $error = array('error' => array('text' => 'Falta dna' )); 
             echo json_encode($error);
             header("HTTP/1.1 403-Forbidden");
        }
          

          
          
    }

    else {

     	//En caso de que ninguna de las opciones anteriores se haya ejecutado

	     $error = array('error' => array('text' => 'Metodo no permitido' )); 
	     echo json_encode($error);
	     header("HTTP/1.1 403-Forbidden");
    }

    //{"ATGCGA","CAGTGC","TTATGT","AGAAGG","CCCCTA","TCACTG"}

    

?>