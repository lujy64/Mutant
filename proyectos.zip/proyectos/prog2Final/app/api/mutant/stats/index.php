<?php
    //Incluir librerias
    include "../../config.php";
    include "../../utils.php";

    //Conexion Base de datos
    $dbConn =  connect($db);

   
    if ($_SERVER['REQUEST_METHOD'] === 'GET')
    {
      
        //Mostrar lista de post
        $sql = $dbConn->prepare("SELECT count(condicion) FROM mutante WHERE condicion='Humano'");
        //echo '<pre>'; print_r($sql); echo '</pre>';
        $sql->execute();
        $sql->setFetchMode(PDO::FETCH_NUM);
        $count_human_dna=$sql->fetchAll()[0][0];

        $sql2 = $dbConn->prepare("SELECT count(condicion) FROM mutante WHERE condicion='Mutante'");
        //echo '<pre>'; print_r($sql2); echo '</pre>';
        $sql2->execute();
        $sql2->setFetchMode(PDO::FETCH_NUM);
        $count_mutant_dna=$sql2->fetchAll()[0][0];


        $ratio= intval($count_mutant_dna)/intval($count_human_dna);
        header("HTTP/1.1 200 OK");

        $mensaje = array('count_mutant_dna' => intval($count_mutant_dna), 'count_human_dna' => intval($count_human_dna), 'ratio' => round($ratio, 1));
        echo json_encode( $mensaje );

        exit();

    } 

    else {

     	//En caso de que ninguna de las opciones anteriores se haya ejecutado

	     $error = array('error' => array('text' => 'Metodo no permitido' )); 
	     echo json_encode($error);
	     header("HTTP/1.1 403-Forbidden");
    }

    //{"ATGCGA","CAGTGC","TTATGT","AGAAGG","CCCCTA","TCACTG"}

    

?>