<?php

//datos de la BD 
$db = [	
    'host' => 'localhost',
    'username' => 'u618411030_lujy64',
    'password' => '123456789Lujy@',
    'db' => 'u618411030_base' 
];

?>