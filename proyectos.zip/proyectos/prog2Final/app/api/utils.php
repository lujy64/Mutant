<?php

    //Funcion donde se busca la igualdad verticalmente
    function secuenciaVertical (array $matriz) {
        $contador=0;
        $coincidencia=0;
        //columnas = [$j]
        //columnas = [$i]
        for ($j=0; $j < count($matriz); $j++) { 
          for ($i = 0; $i< count($matriz)-3; $i++) {
                //Reiniciamos la coincidencia

                //Cogemos el simbolo de la fila
                $simbolo = $matriz[$j][$i];

                //Sino coincide ya no habra semimutante  en esta fila
                if ($simbolo == $matriz[$j][$i+1] && $simbolo == $matriz[$j][$i+2] && $simbolo == $matriz[$j][$i+3]) {
                    $contador = $contador + 1;

                    return $contador;
                } 
            }
        }
            

        return $coincidencia;
    
    }
    
    //Funcion donde se busca la igualdad horizontal
    function secuenciaColumna(array $matriz) {
        
        $contador=0;
        $coincidencia=0;

        for ($i = 0; $i < count($matriz); $i++) {

            for($j=0;$j< count($matriz)-3; $j++){
                
                //Cogemos el simbolo de la fila
                $simbolo = $matriz[$j][$i];
            
                //sino coincide ya no habra mutante en esta fila
                if ($simbolo == $matriz[$j+1][$i]&& $simbolo == $matriz[$j+2][$i] && $simbolo == $matriz[$j+3][$i]) {
                    $contador = $contador + 1;

                    return $contador;
                }
                    
            }
 
        }

        return $coincidencia;
    }

    //Funcion donde se busca la igualdad diagonal 
    function secuenciaDiagonal(array $matriz) {
 
        $contador=0;
        $coincidencia=0;

        
        for($i=0; $i < count($matriz)-3; $i++){
          
            $simbolo = $matriz[$i][$i];
        
            //sino coincide ya no habra mutante en esta fila
            if ($simbolo == $matriz[$i+1][$i+1] && $simbolo == $matriz[$i+2][$i+2] && $simbolo == $matriz[$i+3][$i+3]) {
                  
        $contador = $contador + 1;

        return $contador;
    
            }
        }

        return $coincidencia;
     
    }
     
    //Funcion donde se busca la igualdad diagonal inversa         
    function secuenciaDiagonalInversa(array $matriz) {
       
        $contador=0;
        $coincidencia=0;
        
        for ($i=0;$i< count($matriz)-3;$i++){
            
            for ($j=5;$j>2; $j--){
                
                $simbolo = $matriz[$i][$j];
        
               //sino coincide ya no habra mutante en esta fila
                if ($simbolo == $matriz[$i+1][$j-1] && $simbolo == $matriz[$i+2][$j-2] && $simbolo == $matriz[$i+3][$j-3]) {
                    
              $contador = $contador + 1;

              return $contador;
        }
            }
        }

        return $coincidencia;
    }

    //Funcion general donde obtenemos si es mutante o no
    function isMutant(array $dna){

        $contador=0;
        
        $inverso=0;

        // secuencia en la fila 
        $contador=$contador+secuenciaVertical($dna);
       
        // secuencia en columna
        $secuencia=secuenciaColumna($dna);
        $contador=$contador+$secuencia;

        // secuencia en diagonal
        $secuencia=secuenciaDiagonal($dna);
        $contador=$contador+$secuencia;

        // secuencia en diagonal inversa
        $secuencia=secuenciaDiagonalInversa($dna);
        $contador=$contador+$secuencia;

        if ($contador > 1) {

           $isMutante= 'true';

        } else {

           $isMutante= 'false';

        }

        return $isMutante;
    }

    //Abrir conexion a la base de datos
    function connect($db)
    {
        try {
            $conn = new PDO("mysql:host={$db['host']};dbname={$db['db']};charset=utf8", $db['username'], $db['password']);

            // set the PDO error mode to exception
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            return $conn;
        } catch (PDOException $exception) {
            exit($exception->getMessage());
        }
    }


    //Asociar todos los parametros a un sql
    function bindAllValues($statement, $params)
      {
            foreach($params as $param => $value)
        {
                    $statement->bindValue(':'.$param, $value);
            }
            return $statement;
       }


  

 ?>