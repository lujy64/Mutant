<?php 
	include('functions.php');

	$ADN=$_POST['ADN'];
	$ADN1=$_POST['ADN1'];
	$ADN2=$_POST['ADN2'];
	$ADN3=$_POST['ADN3'];
	$ADN4=$_POST['ADN4'];
	$ADN5=$_POST['ADN5'];

	$adnGuardar=$ADN.$ADN1.$ADN2.$ADN3.$ADN4.$ADN5;
	//echo '<pre>'; print_r($adnGuardar); echo '</pre>';


	$dna = array($ADN, $ADN1, $ADN2, $ADN3, $ADN4, $ADN5);

	$obtenerDna=obtenerMutant();

	
	$obtenerDna=json_decode($obtenerDna);
	//echo '<pre>'; print_r($obtenerDna); echo '</pre>';

	$contador=0;

	for ($i=0; $i < count($obtenerDna); $i++) { 


		if ($adnGuardar === trim((string)$obtenerDna[$i]->dna)) {

			$id=$obtenerDna[$i]->id;

			$contador++;

			//echo '<pre>'; print_r('CONTADOR'); echo '</pre>';
		}else{
			
			//echo '<pre>'; print_r('NO CONTADOR'); echo '</pre>';
		}
	}


	if ($contador > 0) {

		//echo '<pre>'; print_r('ACA'); echo '</pre>';

		header('Location: ../inc/?m=DNA registrado&id='.$id);

	} else {

		$response=ingresarMutant(json_encode($dna));

		$ingresarMutant=json_decode($response);

		$condicion=$ingresarMutant->ok->datos_Resultado->condicion;

		$id=$ingresarMutant->ok->datos_Resultado->id;

		if ($condicion=="Humano"){
				
			header('Location: ../inc/?m=Humano&id='.$id);

	    } else {
	    	header('Location: ../inc/?m=Mutante&id='.$id);
	    }
	}
	


	
	


	
?>