<?php

  if (!empty($_SERVER['HTTPS']) && ('on' == $_SERVER['HTTPS'])) {
    $uri = 'https://';
  } else {
    $uri = 'http://';
  }

  $host=$_SERVER['HTTP_HOST'];
  //echo '<pre>'; print_r($host); echo '</pre>';

  $self=$_SERVER['PHP_SELF'];
  //echo '<pre>'; print_r($self); echo '</pre>';

  $cosa=$_SERVER['REQUEST_URI'];
  //echo '<pre>'; print_r($cosa); echo '</pre>';
  
  
  //echo '<pre>'; print_r($_SERVER['HTTP_HOST']); echo '</pre>';

  if ($_SERVER['HTTP_HOST']=='localhost') {

    $uri=$uri.$host;

  }else if ($_SERVER['HTTP_HOST']=='localhost:88') {
    $uri=$uri.$host;

  }else{
    $uri.= $_SERVER['HTTP_HOST'];

  }

    $uri.="/proyectos/prog2Final";


