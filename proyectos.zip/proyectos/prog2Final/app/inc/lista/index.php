
<?php include('../../controller/functions.php'); ?>
<?php include('../conexion/uri.php'); ?>

<!DOCTYPE html>
<html>
<head>
	<?php include('../conexion/head.php'); 

		$obtener=obtenerMutant();
		$mutants=json_decode($obtener);

		$obtenerEstadisticas=obtenerEstadisticas();
		$estadisticas=json_decode($obtenerEstadisticas);
		
	?>

</head>	
<body>
	<div class="main-wrapper">

       <?php include('../conexion/spinner.php'); ?>
	<div class="auth-wrapper d-flex no-block justify-content-center align-items-center position-relative" style="background:url(<?php echo $uri ?>/assets/img/auth-bg.jpg) no-repeat center;">
        <div class="auth-box row">
            <div class="col-md-12 bg-white">
	                 <div class="card-body">
				        <div class="row col-10 align-self-center">
				            <h3 class="page-title text-truncate text-dark font-weight-medium mt-2"><u>Listado de ADN Ingresado</u></h3><br>
				        </div>
				        <br>
				        <div class="row col-12 align-self-center">
				            <div class="col-md-12">
				            	<div class="table-responsive">
						            <table id="zero_config" class="table table-striped table-bordered no-wrap">
						                <thead>
						                    <tr class="text-center"> 
						                    	<th class="text-left">ID</th>
						                        <th class="text-left">DNA</th>
						                        <th class="text-left">Clasificación</th>
						                       
						                    </tr>
						                </thead>
						                <tbody>
											<?php 
												for ($i=0; $i < count($mutants) ; $i++) { ?>

								                    <tr class="text-center">
								                    	<td  class="text-left"><?php echo $mutants[$i]->id; ?> </td>
								                        <td  class="text-left"><?php echo $mutants[$i]->dna; ?> </td>
								                        <td  class="text-left"><?php echo $mutants[$i]->condicion; ?></td>  
								                    </tr>  

								                <?php	}	?> 
						                        
						                   
						                </tbody>
						            </table>
						        </div>
				            </div>
				            <div class="col-md-12 mt-5">
				            	<div class="row col-10 align-self-center">
						            <h3 class="page-title text-truncate text-dark font-weight-medium mt-2"><u>Estadisticas</u></h3><br>
						        </div><br>
			            		<div class="card-group">
				                    <div class="card border-right card border-top-info">
				                        <div class="card-body">
				                        	
				                            <div class="d-flex d-lg-flex d-md-block align-items-center">
				                                <div>
				                                    <div class="d-inline-flex align-items-center">
				                                        <h2 class="text-dark mb-1 font-weight-medium">
				                                        	<?php 
				                                        		if ($estadisticas->count_mutant_dna=="" && $estadisticas->count_mutant_dna==null) {
				                                        			echo "0";
				                                        		} else {
				                                        			echo $estadisticas->count_mutant_dna;
				                                        		}
				                                        		
				                                        	?>
				                                        </h2>
				                                    </div>
				                                    <h6 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Mutantes</h6>
				                                </div>
				                                <div class="ml-auto mt-md-3 mt-lg-0">
				                                    <span class="opacity-7 text-muted"><i data-feather="user-plus"></i></span>
				                                </div>
				                            </div>
				                        </div>
				                    </div>
				                    <div class="card border-right">
				                        <div class="card-body">
				                            <div class="d-flex d-lg-flex d-md-block align-items-center">
				                                <div>
				                                    <div class="d-inline-flex align-items-center">
				                                        <h2 class="text-dark mb-1 font-weight-medium">
				                                        	<?php 
				                                        		if ($estadisticas->count_human_dna=="" && $estadisticas->count_human_dna==null) {
				                                        			echo "0";
				                                        		} else {
				                                        			echo $estadisticas->count_human_dna;
				                                        		}
				                                        		
				                                        	?>		
				                                        </h2>
				                                    </div>
				                                    <h6 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Humanos</h6>
				                                </div>
				                                <div class="ml-auto mt-md-3 mt-lg-0">
				                                    <span class="opacity-7 text-muted"><i data-feather="file-plus"></i></span>
				                                </div>
				                            </div>
				                        </div>
				                    </div>
				                    <div class="card border-right">
				                        <div class="card-body">
				                            <div class="d-flex d-lg-flex d-md-block align-items-center">
				                                <div>
				                                	<div class="d-inline-flex align-items-center">
				                                    	<h2 class="text-dark mb-1 w-100 text-truncate font-weight-medium">
				                                    		<?php 
				                                        		if ($estadisticas->ratio=="" && $estadisticas->ratio==null) {
				                                        			echo "0";
				                                        		} else {
				                                        			echo $estadisticas->ratio;
				                                        		}
				                                        		
				                                        	?>	
				                                    	</h2>
				                               		</div>
				                                	<h6 class="text-muted font-weight-normal mb-0 w-100 text-truncate">Ratio</h6>
				                                </div>
				                                <div class="ml-auto mt-md-3 mt-lg-0">
				                                    <span class="opacity-7 text-muted"><i data-feather="dollar-sign"></i></span>
				                                </div>
				                            </div>
				                        </div>
				                    </div>
				                </div>
				            </div>
				        </div>
				        
				    </div>
                </div>
         
					 <div class="col-lg-6 text-center mt-3">
	                    <a href="<?php echo $uri ?>/app/inc/"  class="btn btn-block btn-success">Volver</a>
	                </div>
                </div>
            </div>
        </div>
    </div>

   





    <script src="<?php echo $uri ?>/assets/extra-libs/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo $uri ?>/dist/js/pages/datatable/datatable-basic.init.js"></script>
    <script>
        $(".preloader ").fadeOut();
    </script>
	    

    </div>
</body>
</html>