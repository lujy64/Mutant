<?php include('conexion/uri.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?php include('conexion/head.php'); ?>

</head>	
<body>
	<div class="main-wrapper">

       <?php include('conexion/spinner.php'); ?>

        <!-- ============================================================== -->
        <!-- Login box.scss -->
        <!-- ============================================================== -->
	        <div class="auth-wrapper d-flex no-block justify-content-center align-items-center position-relative"
	            style="background:url(<?php echo $uri ?>/assets/img/auth-bg.jpg) no-repeat center;">
	            <div class="auth-box row">
	                <div class="col-md-12 bg-white">
	                    <div class="p-3">
	                        <h2 class="mt-3 text-center">¿Usted es mutante o no?</h2>
	                        <form action="<?php echo $uri ?>/app/controller/index.php" method="POST" class="mt-4">
	                        	<h4 class="mt-2 mb-4"><b><u>Ingresar ADN</u></b></h4>
	                        	<h6 class="card-subtitle">Para indicarle si es mutante, deberia completar los campos solamente con las letras <code>A</code>-<code>T</code>-<code>G</code>-<code>C</code>, ya sea otra letra no mencionada, no obtendrá un resultado correcto. Cada campo tiene un limite de 6 letras.</h6><br>
	                            <div class="row">
	                                <div>
	                                    <div class="form-group">
	                                        <div class="row">
	                                        	<div class="col-md-2">
	                                        		<input class="form-control" id="ADN" name="ADN" type="text" maxlength="6"  required="">
	                                        		<label id="ADNCampo" class="text-center"></label>
	                                        	</div>

	                                        	<div class="col-md-2">
	                                        		<input class="form-control" id="ADN1" name="ADN1" type="text" maxlength="6"  required="">
	                                        		<label id="ADN1Campo" class="text-center"></label>
	                                        	</div>

	                                        	<div class="col-md-2">
	                                        		<input class="form-control" id="ADN2" name="ADN2" type="text" maxlength="6"  required="">
	                                        		<label id="ADN2Campo" class="text-center"></label>
	                                        	</div>

	                                        	<div class="col-md-2">
	                                        		<input class="form-control" id="ADN3" name="ADN3" type="text" maxlength="6"  required="">
	                                        		<label id="ADN3Campo" class="text-center"></label>
	                                        	</div>

	                                        	<div class="col-md-2">
	                                        		<input class="form-control" id="ADN4" name="ADN4" type="text" maxlength="6"  required="">
	                                        		<label id="ADN4Campo" class="text-center"></label>
	                                        	</div>

	                                        	<div class="col-md-2">
	                                        		<input class="form-control" id="ADN5" name="ADN5" type="text" maxlength="6"  required="">
	                                        		<label id="ADN5Campo" class="text-center"></label>
	                                        	</div>
	                                        </div>
	                                    </div>
	                                    <div class=" col-md-12  text-center"><label id="campos" class="text-center"></label></div><br>
	                                </div><br>
	                                <div class="col-lg-12 text-center">
	                                    <button type="submit" id="btnADN" class="btn btn-block btn-dark">Continuar</button>
	                                </div>
	                               <br><br>
	                                
	                            </div>
	                        </form>
	                    </div>

	                </div>
	                <div class="col-lg-6 text-center mt-3">
	                    <a href="<?php echo $uri ?>/app/inc/lista/"  class="btn btn-block btn-success"> Ver registros</a>
	                </div>
	            </div>
	        </div>
        <!-- ============================================================== -->
        <!-- Login box.scss -->
        <!-- ============================================================== -->
        <script src="<?php echo $uri ?>/dist/js/sweetalert.js"></script>
         <script>
	        $(".preloader ").fadeOut();
	    </script>
	    

    </div>
</body>
</html>